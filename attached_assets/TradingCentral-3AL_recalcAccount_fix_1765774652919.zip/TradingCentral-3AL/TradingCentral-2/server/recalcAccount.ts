import { db } from '../db/index';
import { eq, and } from 'drizzle-orm';
import { users, trades } from '../shared/schema';
import { requiredMargin, unrealizedPnl, updateFxRates } from './lib/margin';
import Database from 'better-sqlite3';
import { assertFreshQuotes } from './lib/quoteHealth';

export type RecalcAccountResult = {
  balance: number;
  usedMargin: number;
  equity: number;
  freeMargin: number;
  pricingStale?: boolean;
  staleSymbols?: Array<{ symbol: string; reason: string; ageMs: number | null }>;
  asOf?: number; // ms epoch
};

/**
 * Recalculates account margin metrics (MT5-style):
 * - Used margin (sum of margin required for all open positions)
 * - Equity (balance + unrealized P/L)
 * - Free margin (equity - used margin)
 *
 * Risk-safe policy:
 * - If required quotes are missing or stale, DO NOT recompute MTM.
 * - Return pricingStale=true and do not update DB account metrics.
 */
export async function recalcAccount(userId: number): Promise<RecalcAccountResult | undefined> {
  try {
    const user = await db.query.users.findFirst({ where: eq(users.id, userId) });
    if (!user) {
      console.error(`User ${userId} not found for margin recalculation`);
      return;
    }

    // Open positions only
    const openTrades = await db.query.trades.findMany({
      where: and(eq(trades.userId, userId), eq(trades.status, 'OPEN')),
      with: { symbol: true },
    });

    const balance = parseFloat(user.balance);

    // No open positions: safe to compute without any price feed.
    if (openTrades.length === 0) {
      const usedMargin = 0;
      const equity = balance;
      const freeMargin = balance;

      await db.update(users)
        .set({ usedMargin, equity, freeMargin })
        .where(eq(users.id, userId));

      return { balance, usedMargin, equity, freeMargin, pricingStale: false, asOf: Date.now() };
    }

    // Quotes dependency: strict. If feed is unhealthy, do not update MTM.
    const dbPath = './trading_app.db';

    // Verify quotes table exists
    let hasQuotesTable = false;
    try {
      const dbClient = new Database(dbPath);
      const tables = dbClient.prepare("SELECT name FROM sqlite_master WHERE type='table' AND name='quotes'").all();
      hasQuotesTable = tables.length > 0;
      dbClient.close();
    } catch (error) {
      console.error('Error checking for quotes table:', error);
    }

    // Require quotes table when any open positions exist
    if (!hasQuotesTable) {
      return {
        balance,
        usedMargin: user.usedMargin ?? 0,
        equity: user.equity ?? balance,
        freeMargin: user.freeMargin ?? balance,
        pricingStale: true,
        staleSymbols: openTrades.map(t => ({ symbol: t.symbol.symbol, reason: 'missing_quotes_table', ageMs: null })),
        asOf: Date.now(),
      };
    }

    // Required symbols for safe MTM + FX conversions.
    // NOTE: This is intentionally strict: if these are stale, pricing is treated as stale.
    const fxPairs = ['EURUSD', 'GBPUSD', 'USDJPY', 'USDCAD'];
    const tradeSymbols = [...new Set(openTrades.map(t => t.symbol.symbol))];
    const requiredSymbols = [...new Set([...tradeSymbols, ...fxPairs])];

    const quoteCheck = assertFreshQuotes(dbPath, requiredSymbols);

    if (!quoteCheck.ok) {
      // Refuse to recompute MTM under stale pricing. Keep last-known metrics.
      return {
        balance,
        usedMargin: user.usedMargin ?? 0,
        equity: user.equity ?? balance,
        freeMargin: user.freeMargin ?? balance,
        pricingStale: true,
        staleSymbols: quoteCheck.stale,
        asOf: quoteCheck.now,
      };
    }

    // Keep FX conversion rates fresh for margin/PnL conversions.
    try {
      const fxRows = fxPairs
        .map(sym => quoteCheck.rows.get(sym))
        .filter(Boolean)
        .map((r: any) => ({ symbol: r.symbol, price: r.price }));
      updateFxRates(fxRows as any);
    } catch (e) {
      console.warn('Unable to update FX conversion rates from quotes table:', e);
    }

    // Build a per-symbol quote cache for MTM.
    // IMPORTANT: Do NOT cache a single scalar price per symbol; long and short positions
    // must be marked using different sides (BUY uses BID, SELL uses ASK).
    type QuotePrices = { bid?: number; ask?: number; price?: number; mid?: number };

    const toFinite = (v: any): number | undefined => {
      const n = Number(v);
      return Number.isFinite(n) ? n : undefined;
    };

    const quoteCache = new Map<string, QuotePrices>();

    for (const sym of tradeSymbols) {
      const row = quoteCheck.rows.get(sym);
      if (!row) {
        // Should not happen given assertFreshQuotes; but keep guard.
        return {
          balance,
          usedMargin: user.usedMargin ?? 0,
          equity: user.equity ?? balance,
          freeMargin: user.freeMargin ?? balance,
          pricingStale: true,
          staleSymbols: [{ symbol: sym, reason: 'missing_quote_row', ageMs: null }],
          asOf: quoteCheck.now,
        };
      }

      const bid = row.bid != null ? toFinite(row.bid) : undefined;
      const ask = row.ask != null ? toFinite(row.ask) : undefined;
      const price = row.price != null ? toFinite(row.price) : undefined;
      const mid = bid !== undefined && ask !== undefined ? (bid + ask) / 2 : price;

      quoteCache.set(sym, { bid, ask, price, mid });
    }

    const markPriceFor = (sym: string, side: 'BUY' | 'SELL', fallback: number): number => {
      const p = quoteCache.get(sym);
      if (!p) return fallback;

      // Mark-to-market uses close-out pricing:
      // - BUY positions close on BID
      // - SELL positions close on ASK
      const primary = side === 'BUY' ? p.bid : p.ask;
      const secondary = side === 'BUY' ? p.ask : p.bid;

      return primary ?? p.price ?? p.mid ?? secondary ?? fallback;
    };

    const marginPriceFor = (sym: string, fallback: number): number => {
      const p = quoteCache.get(sym);
      if (!p) return fallback;

      // Margin notional should use a representative tradable price. Prefer mid/price when available.
      return p.price ?? p.mid ?? p.ask ?? p.bid ?? fallback;
    };


    // Calculate used margin and floating P/L
    let usedMargin = 0;
    let floatingProfit = 0;

    for (const trade of openTrades) {
      const sym = trade.symbol.symbol;
      const openPrice = Number(trade.openPrice);

      const lotsFromField =
        typeof trade.lots === 'number' && trade.lots > 0
          ? trade.lots
          : (typeof trade.size === 'number' && trade.size > 0 ? trade.size / 100000 : 0);

      const tradeLots = Number.isFinite(lotsFromField) && lotsFromField > 0 ? lotsFromField : 1;

      // Mark-to-market price uses close-out side (BUY->BID, SELL->ASK).
      const mtmPrice = markPriceFor(sym, trade.type as 'BUY' | 'SELL', openPrice);

      // Margin uses a representative tradable price (mid/price preferred).
      const marginPx = marginPriceFor(sym, openPrice);

      const marginForTrade = requiredMargin(sym, tradeLots, marginPx, user.leverage || 5);
      usedMargin += marginForTrade;

      const pnl = unrealizedPnl(sym, trade.type as 'BUY' | 'SELL', openPrice, mtmPrice, tradeLots);
      floatingProfit += pnl;
    }

    const equity = balance + floatingProfit;
    const freeMargin = Math.max(0, equity - usedMargin);

    await db.update(users)
      .set({ usedMargin, equity, freeMargin })
      .where(eq(users.id, userId));

    return { balance, usedMargin, equity, freeMargin, pricingStale: false, asOf: quoteCheck.now };
  } catch (error) {
    console.error('Error recalculating account metrics:', error);
    throw error;
  }
}
