import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { useEffect } from "react";
import { apiRequest } from "@/lib/queryClient";
import { useAuth } from "./use-auth";
import { useToast } from "./use-toast";
import { useWebSocket } from "./use-websocket";

export function useTrades() {
  const queryClient = useQueryClient();
  const { toast } = useToast();
  const { user } = useAuth();

  // Build WebSocket URL
  const wsUrl =
    (window.location.protocol === "https:" ? "wss://" : "ws://") +
    window.location.host +
    "/ws";

  // Connect to WebSocket for live trade updates
  // Server filters by userId but also sends to unauthenticated clients for new tabs
  const { isConnected: isTradeWsConnected, sendMessage } = useWebSocket(wsUrl, {
    onMessage: (message) => {
      if (!message || typeof message !== "object") return;

      if (message.type === "trades:updated") {
        // Check if this message is for our user (or if no userId filter is present)
        // This handles: 1) matching userId, 2) no userId in message, 3) user not yet loaded
        const messageUserId = message.userId;
        const currentUserId = user?.id;
        
        // Invalidate if: no filter in message, or we don't know our userId yet, or it matches
        if (!messageUserId || !currentUserId || messageUserId === currentUserId) {
          queryClient.invalidateQueries({ queryKey: ["/api/trades"] });
          queryClient.invalidateQueries({ queryKey: ["/api/trades/open"] });
          queryClient.invalidateQueries({ queryKey: ["/api/auth/current-user"] });
          queryClient.invalidateQueries({ queryKey: ["/api/account/summary"] });
        }
      }
    },
  });

  // Send auth info to server so it can filter by userId
  useEffect(() => {
    if (user && sendMessage) {
      sendMessage({ type: "auth", userId: user.id });
    }
  }, [user, sendMessage]);

  // Get all trades
  const { 
    data: trades = [],
    isLoading: isLoadingTrades,
    error: tradesError,
    refetch: refetchTrades 
  } = useQuery({
    queryKey: ["/api/trades"],
    enabled: !!user,
  });

  // Get open trades
  const { 
    data: openTrades = [],
    isLoading: isLoadingOpenTrades,
    error: openTradesError,
    refetch: refetchOpenTrades
  } = useQuery({
    queryKey: ["/api/trades/open"],
    enabled: !!user,
  });

  // Create a new trade
  const createTrade = useMutation({
    mutationFn: async (data: {
      symbolId: number;
      type: "BUY" | "SELL";
      size: number;
      openPrice: number;
      takeProfit?: number;
      stopLoss?: number;
    }) => {
      return apiRequest("POST", "/api/trades", data);
    },
    onSuccess: () => {
      toast({
        title: "Trade Created",
        description: "Your trade was successfully placed",
      });
      // Invalidate queries
      queryClient.invalidateQueries({ queryKey: ["/api/trades"] });
      queryClient.invalidateQueries({ queryKey: ["/api/trades/open"] });
      queryClient.invalidateQueries({ queryKey: ["/api/auth/current-user"] });
      queryClient.invalidateQueries({ queryKey: ["/api/account/summary"] });
    },
    onError: (error: Error) => {
      toast({
        title: "Error",
        description: error.message || "Failed to place trade",
        variant: "destructive",
      });
    },
  });

  // Close a trade
  const closeTrade = useMutation({
    mutationFn: async ({ id }: { id: number }) => {
      // Server computes the authoritative close price from the live quote feed (bid/ask).
      // Do not allow client-side prices to influence execution.
      return apiRequest("POST", `/api/trades/${id}/close`, {});
    },
    onSuccess: () => {
      toast({
        title: "Trade Closed",
        description: "Your trade was successfully closed",
      });
      // Invalidate queries
      queryClient.invalidateQueries({ queryKey: ["/api/trades"] });
      queryClient.invalidateQueries({ queryKey: ["/api/trades/open"] });
      queryClient.invalidateQueries({ queryKey: ["/api/auth/current-user"] });
      queryClient.invalidateQueries({ queryKey: ["/api/account/summary"] });
    },
    onError: (error: Error) => {
      toast({
        title: "Error",
        description: error.message || "Failed to close trade",
        variant: "destructive",
      });
    },
  });

  return {
    trades,
    openTrades,
    isLoadingTrades,
    isLoadingOpenTrades,
    tradesError,
    openTradesError,
    refetchTrades,
    refetchOpenTrades,
    createTrade,
    closeTrade,
  };
}
